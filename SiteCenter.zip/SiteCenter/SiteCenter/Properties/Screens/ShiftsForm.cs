﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SiteCenter.General;

namespace SiteCenter.Properties.Screens
{
    public partial class ShiftsForm : TemplateForm
    {
        public ShiftsForm()
        {
            InitializeComponent();
        }

        private void ShiftsForm_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridView();
        }

        private void LoadDataIntoGridView()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("showshifts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dgvShifts.DataSource = dt;
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsFormValid() == true)
            {
                SavaData();
                clearControll();
            }
        }

        private void SavaData()
        {
            SqlConnection con = new SqlConnection(General.DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("SavaShifts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Timing", txtTiming.Text);
            cmd.Parameters.AddWithValue("@Capacity" , txtCapacity.Text);
            cmd.Parameters.AddWithValue("@CreatedBy", txtCreatedBy.Text);
            cmd.Parameters.AddWithValue("@CreatedDate", dtp.Value);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Saved");
            LoadDataIntoGridView();
            clearControll();
        }

        private bool IsFormValid()
        {
            if (txtTiming.Text == "")
            {
                MessageBox.Show("Shifts timing is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTiming.Focus();
                return false;
            }
            if (txtCapacity.Text == "")
            {
                MessageBox.Show("Capacity Shifts is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCapacity.Focus();
                return false;
            }
            

            return true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clearControll();
        }

        private void clearControll()
        {
            txtTiming.Clear();
            txtID.Clear();
            txtCreatedBy.Clear();
            txtCapacity.Clear();
            saveToolStripMenuItem.Enabled = true;
            updateToolStripMenuItem.Enabled = false;
            deleteToolStripMenuItem.Enabled = false;

        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updateData();
        }

        private void updateData()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("updateshifts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@ShiftID", txtID.Text);
            cmd.Parameters.AddWithValue("@Timing", txtTiming.Text);
            cmd.Parameters.AddWithValue("@Capacity", txtCapacity.Text);
            cmd.Parameters.AddWithValue("@CreatedBy", txtCreatedBy.Text);
            cmd.Parameters.AddWithValue("@CreatedDate", dtp.Value);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data update Succus", "done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadDataIntoGridView();
            clearControll();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {



            if (txtID.Text != string.Empty)
            {
                //delete
                Deletedata(); 
                MessageBox.Show("Delete Successfull");
                clearControll();
                LoadDataIntoGridView();
            }
            else
            {
                MessageBox.Show("please select student to delete", "Valid", MessageBoxButtons.OK, MessageBoxIcon.Question);
            }

           
        }

        private void Deletedata()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("deleteShifts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            cmd.Parameters.AddWithValue("@ShiftID", txtID.Text);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void dgvShifts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(dgvShifts.Rows.Count>0)
            {
                try
                {
                    txtID.Text = dgvShifts.CurrentRow.Cells[0].Value.ToString();
                    txtTiming.Text = dgvShifts.CurrentRow.Cells[1].Value.ToString();
                    txtCapacity.Text = dgvShifts.CurrentRow.Cells[2].Value.ToString();
                    txtCreatedBy.Text = dgvShifts.CurrentRow.Cells[3].Value.ToString();
                    dtp.Value = Convert.ToDateTime(dgvShifts.Rows[e.RowIndex].Cells[4].Value.ToString());
                    saveToolStripMenuItem.Enabled = false;
                    updateToolStripMenuItem.Enabled = true;
                    deleteToolStripMenuItem.Enabled = true;
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }

            }
           
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (txtSearch.Text != "")
            {
                //Search operation
                SqlConnection con = new SqlConnection(DbConnection.GetConnection());
                string query = "select * from Shifts where Timing Like '%'+'" + txtSearch.Text + "'+'%'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvShifts.DataSource = dt;
                con.Open();


                con.Close();
            }
        }

        private void dgvShifts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
