﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using SiteCenter.General;

namespace SiteCenter.Properties.Screens
{
    public partial class AddStudents : TemplateForm
    {
        public AddStudents()
        {
            InitializeComponent();
        }
        public int StudentID { get; set; }
        public int MyProperty { get; set; }
        private void AddStudents_Load(object sender, EventArgs e)
        { 
            if(StudentID>0)
            {
                MessageBox.Show("Student is " + StudentID);
            }
            
            LoadDataIntoComboBoxes();
            LoadShfitsIntoCoboBoxes();
            LoadDataCourseIntoComboBoxes();
        }

        private void LoadDataCourseIntoComboBoxes()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("loadCourse", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbCourse.DataSource = dt;
            cmbCourse.DisplayMember = "CourseName";
            cmbCourse.ValueMember = "CourseID";
            cmbCourse.SelectedIndex = -1;
        }

        private void LoadShfitsIntoCoboBoxes()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("LoadShifts", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbShifts.DataSource = dt;
            cmbShifts.DisplayMember = "Timing";
            cmbShifts.ValueMember = "ShiftID";
            cmbShifts.SelectedIndex = -1;
        }

        private void LoadDataIntoComboBoxes()
        {
            SqlConnection con = new SqlConnection(DbConnection.GetConnection());
            SqlCommand cmd = new SqlCommand("usp_LoadGenders", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            cmbGender.DataSource = dt;
            cmbGender.DisplayMember = "Gender";
            cmbGender.ValueMember = "GenderID";
            cmbGender.SelectedIndex = -1;




            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //DataTable dtGenders = new DataTable();
            //da.Fill(dtGenders);
            //cmbGender.DataSource = dt;
            //cmbGender.DisplayMember = "Gender";
            //cmbGender.ValueMember ="GenderID";
            //cmbGender.SelectedIndex = -1;

        }
    
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void viewStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewStudents vs = new ViewStudents();
            vs.ShowDialog();
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClearControll();

        }

        private void ClearControll()
        {
            txtAddress.Clear();
            txtCaste.Clear();
            txtCnic.Clear();
            txtcreatedByS.Clear();
            txtFatherName.Clear();
            txtID.Clear();
            txtMobileNo.Clear();
            txtPhoneNo.Clear();
            txtQualification.Clear();
            txtStdName.Clear();
            DOB.Value = DateTime.Now;
            DtpAdmision.Value = DateTime.Now;
            DtpCratedDate.Value = DateTime.Now;
            cmbCourse.SelectedItem = null;
            cmbGender.SelectedItem = null;
            cmbShifts.SelectedItem = null;

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsFormValid() == true)
            {
                SaveRecord();
                ClearControll();
              
            }
        }

        private void SaveRecord()
        {
            try
            {
                SqlConnection con = new SqlConnection(DbConnection.GetConnection());
                SqlCommand cmd = new SqlCommand("usp_StudentInsertStudent", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudentName", txtStdName.Text);
                cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text);
                cmd.Parameters.AddWithValue("@Caste", txtCaste.Text);
                cmd.Parameters.AddWithValue("@GenderID", cmbGender.SelectedValue);
                cmd.Parameters.AddWithValue("@DateOfBirth", DOB.Value.ToShortDateString());
                cmd.Parameters.AddWithValue("@CnicNo", txtCnic.Text);
                cmd.Parameters.AddWithValue("@PhoneNo", txtPhoneNo.Text);
                cmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Text);
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@DateOfAdmission", DtpAdmision.Value.ToShortDateString());
                cmd.Parameters.AddWithValue("@CourseID", cmbCourse.SelectedValue);
                cmd.Parameters.AddWithValue("@ShiftID", cmbShifts.SelectedValue);
                cmd.Parameters.AddWithValue("@Qualification", txtQualification.Text);
                cmd.Parameters.AddWithValue("@Photo", (StudentPictureBox.Image == null) ? System.Data.SqlTypes.SqlBinary.Null : ImageManipulation.GetPhoto(StudentPictureBox));
                cmd.Parameters.AddWithValue("@CreatedBy", txtcreatedByS.Text);
                con.Open();    
                if(cmd.ExecuteNonQuery()>0)
                {
                    MessageBox.Show("Data Saved");
                    con.Close();
                }    
                else
                {
                    MessageBox.Show("error");
                    con.Close();
                }


            }
            catch (Exception EX)
            {

                MessageBox.Show(EX.Message);
            }
        }

        private bool IsFormValid()
        {
            if (txtStdName.Text == "")
            {
                MessageBox.Show("Student Name is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtStdName.Focus();
                return false;
            }
            if (txtFatherName.Text == "")
            {
                MessageBox.Show("Student Father Name  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFatherName.Focus();
                return false;
            }
            if (txtCaste.Text == "")
            {
                MessageBox.Show("Student Caste   is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCaste.Focus();
                return false;
            }
            if (cmbGender.Text == "")
            {
                MessageBox.Show("Gender  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbGender.Focus();
                return false;
                if (DOB.Text == "")
                {
                    MessageBox.Show("Student Date of birth  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DOB.Focus();
                    return false;
                    if (txtCnic.Text == "")
                    {
                        MessageBox.Show("Student CNIC  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtCnic.Focus();
                        return false;
                    }
                    if (txtPhoneNo.Text == "")
                    {
                        MessageBox.Show("Student Phone number  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtPhoneNo.Focus();
                        return false;
                        if (txtMobileNo.Text == "")
                        {
                            MessageBox.Show("Student Mobile Number  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtMobileNo.Focus();
                            return false;
                        }
                        if (txtAddress.Text == "")
                        {
                            MessageBox.Show("Student Address  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtAddress.Focus();
                            return false;
                        }
                        if (cmbCourse.Text == "")
                        {
                            MessageBox.Show("Student Course  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            cmbCourse.Focus();
                            return false;
                        }
                        if (cmbShifts.Text == "")
                        {
                            MessageBox.Show("Student Shifts  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            cmbShifts.Focus();
                            return false;
                        }
                        if (txtQualification.Text == "")
                        {
                            MessageBox.Show("Student Qualification  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtQualification.Focus();
                            return false;
                        }
                        if (DtpAdmision.Text == "")
                        {
                            MessageBox.Show("Student Admission date  is Required", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            DtpAdmision.Focus();
                            return false;
                        }
                       

                    }
                }
                

            }
            return true;
        }

        private void btnbrowase_Click(object sender, EventArgs e)
        {
            BrowsePicture.BrowsePic(StudentPictureBox);        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
    }

    

