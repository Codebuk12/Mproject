﻿using SiteCenter.Properties.Screens;
using SiteCenter.Screens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SiteCenter
{
    public partial class DashboardScreen : TemplateForm
    {
        public DashboardScreen()
        {
            InitializeComponent();
        }

        private void addNewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewUserScreen addnew = new AddNewUserScreen();
            addnew.ShowDialog();
        }

        private void manageCourseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ManageCoursesScreen course = new ManageCoursesScreen();
            course.ShowDialog();
        }

        private void DashboardScreen_Load(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void shiftsToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void mToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShiftsForm  f = new ShiftsForm();
            f.ShowDialog();
        }

        private void courseToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void manageStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddStudents a = new AddStudents();
            a.ShowDialog();
        }

        private void feeTyperToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void staffToolStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void manageStaffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Staff s = new Staff();
            s.ShowDialog();
        }

        private void feeRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void manageFeeRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeeRecord rf = new FeeRecord();
            rf.ShowDialog();
        }

        private void manageFeeTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeeType Ft = new FeeType();
            Ft.ShowDialog();
        }
    }
}
